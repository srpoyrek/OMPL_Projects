import numpy as np
from matplotlib import pyplot as plt
from matplotlib import animation
import matplotlib.patches as patches

def get_max(lists):
    max = len(lists[0])
    for list in lists:
        if len(list) > max:
            max = len(list)

    return max

# First set up the figure, the axis, and the plot element we want to animate
fig = plt.figure()
ax = plt.axes(xlim=(-2, 2), ylim=(-2, 2))
line, = ax.plot([], [], lw=2)
patch = plt.Circle((1,1), 0.75, fc='y')
patch2 = plt.Circle((1,1), 0.75, fc='b')
ax.set_aspect('equal')

paths = [[(1,2), (1,-1), (0,0)],[(2,2),(2,1),(1,-1)]]
inter_path_xs = []
inter_path_ys = []
inter_path_x = []
inter_path_y = []
for path in paths:
    path1 = path[:-1]
    path2 = path[1:]
    inter_path_x = []
    inter_path_y = []
    for points1, points2 in zip(path1, path2):
        interval = 0.25
        if int(points1[0]) == int(points2[0]):
            size = np.ceil(abs(points2[1] - points1[1])/interval)
        else:
            size = np.ceil(abs(points2[0] - points1[0]) / interval)
        if int(size) == 0:
            size = 5
        if int(points1[0]) == int(points2[0]):
            inter_path_x += [points1[0]]*int(size)
        else:
            inter_path_x += np.linspace(points1[0], points2[0], size).tolist()
        if int(points1[1]) == int(points2[1]):
            inter_path_y += [points1[1]] * int(size)
        else:
            inter_path_y += (np.linspace(points1[1], points2[1], size)).tolist()
    inter_path_xs.append(inter_path_x)
    inter_path_ys.append(inter_path_y)

    print (inter_path_xs)
    print (inter_path_ys)

maxlength = get_max(inter_path_xs)
print(maxlength)
print(inter_path_xs[0])

# initialization function: plot the background of each frame
def init():
    line.set_data([], [])
    patch.center = (inter_path_xs[0][0], inter_path_ys[0][0])
    patch2.center = (inter_path_xs[1][0], inter_path_ys[1][0])
    ax.add_patch(patch)
    ax.add_patch(patch2)
    return patch,patch2,

# animation function.  This is called sequentially
def animate(i):
    x = np.linspace(0, 2, 1000)
    y = np.sin(2 * np.pi * (x - 0.01 * i))
    line.set_data(x, y)
    # print(i)
    if i < len(inter_path_xs[0]):
        b = i
    else:
        b = len(inter_path_xs[0]) - 1
    patch.center = (inter_path_xs[0][b], inter_path_ys[0][b])
    if i < len(inter_path_xs[1]):
        b = i
    else:
        b = len(inter_path_xs[1]) - 1
    patch2.center = (inter_path_xs[1][b], inter_path_ys[1][b])
    print(i)
    return patch,patch2

# call the animator.  blit=True means only re-draw the parts that have changed.
anim = animation.FuncAnimation(fig, animate, init_func=init,
                               frames=maxlength, interval=60, blit=True)

# save the animation as an mp4.  This requires ffmpeg or mencoder to be
# installed.  The extra_args ensure that the x264 codec is used, so that
# the video can be embedded in html5.  You may need to adjust this for
# your system: for more information, see
# http://matplotlib.sourceforge.net/api/animation_api.html
# anim.save('basic_animation.mov', fps=30, extra_args=['-vcodec', 'libx264'])

plt.show()