# imports
from math import cos, sin, atan2, radians, degrees, sqrt, hypot
import random
import time
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.patches as patches
from matplotlib.patches import Circle, Wedge, Polygon

import funcs
from funcs import plotRect, check_vert, getRVO, no_collision, distance, \
					circ_intersection, dot_prod, integrate, form_roadmap, plot_roadmap

# Plotting Section
fig = plt.figure()
ax = plt.axes(xlim=(-2, 15), ylim=(-2, 15))
ax.set_aspect('equal')

# Max distance to be considered neighbours
N_dist = 15
Max_vel = 4
t_step = 0.1
retries = 100
goal_radius = 0.02
circles = []
col = 'g'
do_road_map = False
R_patches = []
R2_patches = []
vel_range = []

# rectList = [[-8,-7,4,4],[8,-7,4,4],[-8,3,4,4],[8,3,4,4]]
# rectList = []
#rectList = [[-10,-10,20,2], [-10,-8,2,7], [8, -8, 2, 6], [-10, -2, 8, 4], [2, -2, 8, 4] , [-10, 2, 2, 6], [8,2, 2,6], [-10, 8, 20, 2]] # I obstacle
rectList = []
test = rectList + [[-2,-2,8,7]]
road_map = []
goal_points = []


#Robot Class
class Robot:
	def __init__(self, radius, ro_id, start, goal, road_map=None):
		self.radius = radius
		self.neighbours = []
		self.velocity = (0,0)
		self.start = start if road_map is None else road_map[0]
		self.goal = goal
		self.trajectory = [start]
		self.location = start
		self.id = ro_id

		self.RVOs = []
		self.RVO_patches = []

		self.road_map = road_map if road_map is not None else [start,goal]
		self.near_goal = road_map[1] if road_map is not None else goal
		self.index = 1 # keeps track of location in road map
		

	def set_velocity(self, velocity):
		self.velocity = (velocity[0]*t_step, velocity[1])

	def set_loc(loaction):
		self.location = location

	def get_loc(self):
		return self.location

	def get_id(self):
		return self.id

	def get_vel(self):
		return self.velocity

	def update_neighbours(self, robots):
		self.neighbours = []
		for robot in robots:
			mag,_ = distance(self.location, robot.get_loc())
			if (mag < N_dist) and (self.id != robot.get_id()):
				self.neighbours.append(robot)

	# Get preferred velocity of robot
	def get_pref_vel(self, goal=None):
		print("get pref vel")
		if goal is None:
			goal = self.goal
		mag,theta = distance(self.location, goal)
		if mag > Max_vel:
			mag = Max_vel

		return mag, theta

	def is_pref_valid(self):
		pass

	def is_at_goal(self, goal=None):
		if goal is None:
			goal = self.goal
		x, y = self.location
		gx, gy = goal
		if (abs(x - gx) < goal_radius) and (abs(y - gy) < goal_radius):
			return True

	def set_ideal_vel(self, road_map_bool=False):
		r_range = 90
		# check if preferred velocity is valid
		if road_map_bool:
			pref = self.get_pref_vel(self.near_goal)
		else:
			pref = self.get_pref_vel()

		pref_mag, pref_theta = pref
		
		print("pref mag", pref[0], "pref theta", degrees(pref[1]), "goal is ", self.goal)

		A = self.location
		B = self.new_loc((Max_vel,(pref_theta - radians(r_range))))
		C = self.new_loc((Max_vel,(pref_theta + radians(r_range))))

		# Draw triangle with velocity ranges
		p = plt.Polygon([A, B, C], alpha = 0.0, color='r')
		vel_range.append(p)
		ax.add_patch(p) 

		# Check if preferred velocity intersects with any robots velocity obstacle or RVO
		valid = self.no_rov_in(pref)
		if valid:
			px,py = self.new_loc(pref)
			valid = no_collision(px,py,self.get_radius(),rectList)
			if not valid: print("collision with obstacle","px", px, "py", py, "radius", self.get_radius())

		if valid:
			print("Valid")
			# self.move_robot(pref)
			return pref
			
		else:
			
			for i in range(0, retries):
				# sample  velocities out of available velocities
				mag  = random.uniform(-Max_vel, Max_vel)
				theta = random.uniform(pref_theta - radians(r_range), pref_theta + radians(r_range))

				valid = self.no_rov_in((mag, theta))
				# Check if velocities intersect obstacles
				if valid:
					px,py = self.new_loc((mag, theta))
					valid = no_collision(px,py,self.get_radius(), rectList)

				if valid:
					# self.move_robot((mag, theta))
					return mag, theta

				print("Invalid velocity", mag, theta)
				print("InValid")

			# If there is no path robot stays still
			# self.move_robot((0,0))
			return (0,0)

	def set_near_goal(self, road_map=None):
		if road_map is None:
			road_map = self.road_map
		if self.index < (len(road_map)):
			self.index += 1

		self.near_goal = road_map[self.index]
		
	def set_close_goal(self, r_map = None):
		if r_map is None:
			r_map = self.road_map
		i = 1
		dist,_ = distance(self.location, self.near_goal) 
		d = 0
		# road map optimization. Starts moving to the nearest point in path it is close to and that it has not
		# visited before
		for goal in r_map[self.index+1:]:
			n_dist,_ = distance(self.location, goal)
			if n_dist < dist:
				dist = n_dist
				d = i
			i += 1

		self.index += d
		self.near_goal = r_map[self.index]


	def follow_map(self):
		if self.index < (len(road_map)-1):
			self.set_close_goal()

		if self.is_at_goal(self.near_goal):
			self.set_near_goal()

		return self.set_ideal_vel(road_map_bool=True)


	def no_rov_in(self, vel):
		for ROV in self.RVOs:
			Px,Py = self.new_loc(vel)
			A,B,C = ROV[0], ROV[1], ROV[2]
			Ax,Ay = A
			Bx,By = B
			Cx,Cy = C

			numerator = Ax * (Cy - Ay) + (Py - Ay) * (Cx - Ax) -  Px * (Cy - Ay)
			denomenator = (By - Ay) * (Cx - Ax) - (Bx - Ax) * (Cy - Ay)

			w1 = numerator / denomenator

			numerator = Py - Ay - w1 * (By - Ay)
			denomenator = Cy - Ay

			w2 = numerator / denomenator
			
			if w1 >= 0 and w2 >= 0 and (w1 + w2) <= 1: 
				return False

		return True

	def get_radius(self):
		return self.radius

	def update_rov_obstacles(self):
		self.RVOs = []
		for p in self.RVO_patches:
			p.remove()

		self.RVO_patches = []
		for neighbour in self.neighbours:
			r = neighbour.get_radius()
			RVO = getRVO(self, neighbour, ax, R_patches, R2_patches)
			self.RVOs.append(RVO)
			print("ROV is", RVO)
			p = plt.Polygon(RVO, alpha = 0.0, color=(0.5,0.5,0))
			self.RVO_patches.append(p)
			ax.add_patch(p)
			# p.set_visible(False)

	# Update robot to new location based on velocity
	def move_robot(self, velocity):
		#self.set_velocity((velocity[0]*t_step, velocity[1]))
		self.location = integrate(self.location, velocity, t_step)
		self.trajectory.append(self.location)

	# returns location robot will be in if it moves for a certain velocity in 
	# a certain time step
	def new_loc(self,velocity):
		return integrate(self.location, velocity, t_step)

	def new_loc_2(self,velocity):
		return integrate(self.location, velocity)


# ------------------------ MAIN ------------------------ #
if __name__ == "__main__":
	# starts = [(10,10), (10, -10)] #, (-10, -10), (-10,10), (-10,0), (10,0),  (0,10), (0,-10)] #, ( -1,-1), (-1, 1)]
	# goals = [(-10,-10), (-10,10)] # , (10,10), (10,-10), (10,0), (-10,0),(0,-10),(0,10) ] #, (1,1), (1,-1)]

	starts = [(-5,5), (5,-5), (5,5), (-5,-5)]
	goals = [(5,-5), (-5,5), (-5,-5), (5,5)]
	starts = [[1,1],[1,3],[3,3],[3,1],[1,10],[1,12],[3,12],[3,10],[10,10],[10,12],[12,12],[12,10],[10,1],[10,3],[12,3],[12,1]]
	goals  = [[10,10],[10,12],[12,12],[12,10],[10,1],[10,3],[12,3],[12,1],[1,1],[1,3],[3,3],[3,1],[1,10],[1,12],[3,12],[3,10]]
	rectList = [[4,4,1.2,1.2], [4,7,1.2,1.2], [7,7,1.2,1.2],[7,4,1.2,1.2]]
	robots = []
	radius = 0.5 #1.5
	finished = False
	patches = []
	lines = []
	arrows = []
	points = [(5,2),(1,3), (1,4)]	
	headlen = 0.5
	r_vels = []
	directory = "paths"

	do_road_map = False
	big_x, big_y = 0,0
	num_circles = 16
	big_rad = 80
	# starts, goals = funcs.plotRing(radius, big_x,big_y,num_circles,big_rad)
	# print(starts)
	# print()
	# print(goals)

	road_maps = funcs.readPaths(directory)

	plotRect(rectList, ax)

	# print(len(road_map))

	if do_road_map:
		plot_roadmap(ax, road_maps)
		starts = [0] * len(road_maps)
		goal = [0] * len(road_maps)
	else:
		road_maps = [0] * len(starts)

	print(road_maps, "\n",starts,"\n", goals)
	
	i = 0 # id of robots
	incr = 1 / num_circles
	col = 0
	for start, goal, road_map in zip(starts, goals, road_maps):

		if do_road_map:
			robots.append(Robot(radius, i, road_map[0], road_map[-1], road_map))
		else:
			robots.append(Robot(radius, i, start, goal))

		if do_road_map:
			patch = plt.Circle(road_map[0], radius, color=(col,0,col))
		else:
			patch = plt.Circle(start, radius, color=(col,0,col))

		col += incr

		a = plt.arrow(0,0,0,0)
		arrows.append(a)
		patches.append(patch)
		ax.add_patch(patch)
		ax.add_patch(a)
		line, = ax.plot([], [], lw=2)
		line.set_data([], [])
		lines.append(line)
		circles.append(None)
		r_vels.append((0,0))

		if do_road_map:
			patch = plt.Circle(road_map[0], 0.1, color=(col,0,col))
			goal_points.append(patch)
			ax.add_patch(patch)
		i += 1

	print("out of loop")
	print("robot len and patch len", len(robots), len(patches))

	# Navigating robots to the goal position
	count = 0

	start_time = time.time()

	loop = True
	if loop:
		while(not finished):
			# Calculate velocity for all points 
			i = 0
			finished = True
			
			for robot,patch in zip(robots, patches):
				patch.center = (robot.get_loc())

			r_vels = []
			i = 0
			for robot,patch, in zip(robots, patches):
				print("in for")
				in_loc = robot.get_loc()
				robot.update_neighbours(robots)
				robot.update_rov_obstacles()
				if i == 0:
					col = 'g'
				else:
					col = 'r'
				if not robot.is_at_goal():
					if do_road_map:
						vel = robot.follow_map()
					else:
						vel = robot.set_ideal_vel()
					print("robot", robot.get_id(), "now at", robot.get_loc())
					finished = False
				else: # robot is at goal so keep robot still
					vel = (0,0)
					print(robot.get_id(), "is at goal")
				print()
				r_vels.append(vel)

				if vel[0] > 0:
					new_x, new_y = robot.new_loc_2((vel[0]-headlen,vel[1]))
				robot.set_velocity(vel)
				i += 1
		
			i = 0
			for robot, r_vel in zip(robots, r_vels):
				in_loc = robot.get_loc()
				loc_x, loc_y = in_loc
				new_x, new_y = robot.new_loc(r_vel)
				x = [loc_x,new_x]
				y = [loc_y, new_y]
				lines[i].set_data(x, y)

				if do_road_map:
					goal_points[i].center = (robot.near_goal[0], robot.near_goal[1])
				i += 1

			plt.pause(0.004)
			for p,p2 in zip(R_patches, R2_patches):
				p.remove()
				p2.remove()

			for p in vel_range:
				p.remove()
			R_patches = []
			R2_patches = []
			vel_range = []

			j = 0
			for robot, vel in zip(robots, r_vels):		
				robot.move_robot(vel)
				j += 1

			count +=1	


	elapsed_time = time.time() - start_time	
	print("time elapsed", elapsed_time)

	plt.show()
