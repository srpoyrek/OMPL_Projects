///////////////////////////////////////
// COMP/ELEC/MECH 450/550
// Project 2
// Author::Rhema Ike
//////////////////////////////////////

#include "CollisionChecking.h"

#define PI 3.14159265

// Intersect the point (x,y) with the set of rectangles. If the point lies outside of all obstacles, return true.
bool isValidPoint(double x, double y, const std::vector<Rectangle> &obstacles)
{
    Rectangle rect; double x1, x2, y1, y2 = 0;
    for(int i = 0; i < obstacles.size(); i++){
	rect = obstacles[i];
	x1 =  rect.x;
	x2 = rect.x + rect.width;
	y1 = rect.y;
	y2 = rect.y + rect.height;
	if((x >= x1 && x <= x2) && (y >= y1 && y <= y2 )){
		return false;
	}
    }
    return true;
}

// Intersect a circle with center (x,y) and given radius with the set of rectangles. If the circle lies outside of all
// obstacles, return true.
bool isValidCircle(double x, double y, double radius, const std::vector<Rectangle> &obstacles)
{
    // TODO:: IMPLEMENT ME!!
    Rectangle rect; double n1, n2, n3, n4, x1, x2, y1, y2 = 0; int power = 2;
    for(int i = 0; i < obstacles.size(); i++){
	rect = obstacles[i];
	x1 =  rect.x;
	x2 = rect.x + rect.width;
	y1 = rect.y;
	y2 = rect.y + rect.height;
	if((x >= (x1 - radius) && x <= (x2 + radius)) && (y >= y1 && y <= y2 )){
		return false;
	}
	if((x >= x1 && x <= x2) && (y >= (y1 - radius) && y <= (y2 + radius))){
		return false;
	}
	n1 = sqrt(pow((x - x1), power) + pow((y - y1), power));
	n2 = sqrt(pow((x - x2), power) + pow((y - y1), power));
	n3 = sqrt(pow((x - x1), power) + pow((y - y2), power));
	n4 = sqrt(pow((x - x2), power) + pow((y - y2), power));
	if (n1 <= radius || n2 <= radius || n3 <= radius || n4 <= radius){
		return false;
	}
    }
    return true;

}

// Intersect a square with center at (x,y), orientation theta, and the given side length with the set of rectangles. If
// the square lies outside of all obstacles, return true.
bool isValidSquare(double x, double y, double theta, double sideLength, const std::vector<Rectangle> &obstacles)
{
    // TODO:: IMPLEMENT ME!
    // mira por todos de los obstaculos
    Rectangle rect; double r1x, r1y, r2x, r2y, r3x, r3y, r4x, r4y, x1, x2, y1, y2, maxY, minY, maxX, minX, angle_check = 0;
    double tol = 0.00001;
    int normal = 0;
    double temp = 0;
    int alligned = 0;
    int y_lap, x_lap = 0;
    double faces[8][2];
    int count = 0;

    for(int i = 0; i < obstacles.size(); i++){
	normal = 0;
	y_lap = 0;
	x_lap = 0;
	alligned = 0;
	count++;

	rect = obstacles[i];
	x1 =  rect.x;
	x2 = rect.x + rect.width;
	y1 = rect.y;
	y2 = rect.y + rect.height;

	if (theta > 0) {angle_check = fmod(theta, (PI/2));}
	if (theta < 0) {angle_check = fmod(-1*theta, (PI/2));}

	// checking to see if square is slanted 
	if ((angle_check >= ((PI/2)-tol) && angle_check <= ((PI/2)+tol)) || angle_check == 0){
		normal = 1;
	}

	// getting the points of the square
	// bottom left
	r1x = -1*sideLength/2; r1y = -1*sideLength/2;

	// top left
	r2x = -1*sideLength/2; r2y = sideLength/2;

	// bottom right
	r3x = sideLength/2; r3y = sideLength/2;

	// top left
	r4x = sideLength/2; r4y = -1*sideLength/2;

	// translating robot by theta
	if (!normal){
		temp = r1x; r1x = (cos(theta) * r1x) + (-1*sin(theta) * r1y); r1y = (sin(theta) * temp) + (cos(theta) * r1y);
		temp = r2x; r2x = (cos(theta) * r2x) + (-1*sin(theta) * r2y); r2y = (sin(theta) * temp) + (cos(theta) * r2y);  	
		temp = r3x; r3x = (cos(theta) * r3x) + (-1*sin(theta) * r3y); r3y = (sin(theta) * temp) + (cos(theta) * r3y);  	
		temp = r4x; r4x = (cos(theta) * r4x) + (-1*sin(theta) * r4y); r4y = (sin(theta) * temp) + (cos(theta) * r4y);  	
	}
	
	//Translate square robot
	r1x = r1x + x; r1y = r1y + y;
	r2x = r2x + x; r2y = r2y + y;
	r3x = r3x + x; r3y = r3y + y;
	r4x = r4x + x; r4y = r4y + y;

	maxY = r1y; maxY  = std::max(maxY,r2y); maxY = std::max(maxY,r3y); maxY = std::max(maxY,r4y);
	minY = r1y; minY  = std::min(minY,r2y); minY = std::min(minY,r3y); minY = std::min(minY,r4y);
	
	maxX = r1x; maxX  = std::max(maxX,r2x); maxX = std::max(maxX,r3x); maxX = std::max(maxX,r4x);
	minX = r1x; minX  = std::min(minX,r2x); minX = std::min(minX,r3x); minX = std::min(minX,r4x);

	// check for projections on the x and y axis. Just because there is an overlab in both 
	// does not mean there configuration is invalid unless the robot is not tilted
	if ((y1 >= minY && y1 <= maxY) || (y2 >= minY && y2 <= maxY) || (maxY >= std::min(y1,y2) && maxY <= std::max(y1,y2)) || (minY >= std::min(y1,y2) && minY <= std::max(y1,y2))) {
		y_lap = 1;
	}
	if ((x1 >= minX && x1 <= maxX) || (x2 >= minX && x2 <= maxX) || (maxX >= std::min(x1,x2) && maxX <= std::max(x1,x2)) || (minX >= std::min(x1,x2) && minX <= std::max(x1,x2))) {
		x_lap = 1;
	}

	// if there was no overlap in both y_lap and x_lap there configuration is valid
	if ((y_lap + x_lap) < 2){
		continue;
	}
		// if the obstacle is not slanted and there is an over lap in projection in y and x axis then there is an intersection
	if(normal && y_lap && x_lap){
		return false;
	}	

	// ---- Handling case when x is rotated. ----
	
	// I will project obstacle and robot on to a line that is perpendicular to one of the faces of the robot
	// If there is an axis where the projection is not overlapping then the configuration is valid.
	//
	// Because the robot is a square getting a lines perpendicular to each of the faces is very trivial
	// as neighbouring faces are perpendicular to each other
	//
	// To make it easy for me to project the points on the obstacles on the axis I will
	// shift the axis so it is it intersects the origin. Then using the dot product I will 
	// find the projection of the vector going to the point on to any vector parallel to the 
	// now translated axis
	//
	// Vamos a Empezar
	faces[0][0] = r1x ; faces[0][1] = r1y;
	faces[1][0] = r2x ; faces[1][1] = r2y;
	faces[2][0] = r2x ; faces[2][1] = r2y;
	faces[3][0] = r3x ; faces[3][1] = r3y;
	faces[4][0] = r3x ; faces[4][1] = r3y;
	faces[5][0] = r4x ; faces[5][1] = r4y;
	faces[6][0] = r4x ; faces[6][1] = r4y;
	faces[7][0] = r1x ; faces[7][1] = r1y;	


	int k = 1;
	double m = 0;
	int count2 = 0;
	double axis_x, axis_y = 0;
	int good_axis = 0;
	double norm, dot_prod1, dot_prod2, dot_prod3, dot_prod4,  n1x, n1y, n2x, n2y, n3x, ny3, nx4 = 0;
	double proj1x, proj1y, proj2x, proj2y, proj3x, proj3y, proj4x, proj4y, normp1, normp2, normp3, normp4 = 0;
	double dotr1, dotr2, chn1, chn2, rn1, rn2, rp1x, rp1y, rp2x, rp2y, chp1x, chp1y, chp2x, chp2y;	
	
	// going through each axis out of four that are perpendicular to a face
	for (int j = 0; j < 4; j = j + 2){

		k = j + 1;
		m = (faces[k][1] - faces[j][1])/(faces[k][0] - faces[j][0]);
		axis_x = 1;
		axis_y = m * axis_x;
		
	
		// projecting all 4 points unto line perpendicular face of square
		// fisrt getting the dot product
		dot_prod1 = (axis_x * x1) + (axis_y * y1);
		dot_prod2 = (axis_x * x1) + (axis_y * y2);
		dot_prod3 = (axis_x * x2) + (axis_y * y2);
		dot_prod4 = (axis_x * x2) + (axis_y * y1);
		dotr1 = (axis_x * faces[j][0]) + (axis_y * faces[j][1]); // dot product of first point on rectangle
		dotr2 = (axis_x * faces[k][0]) + (axis_y * faces[k][1]); // dot product of second point on rectangle	

		norm = sqrt(pow(axis_x,2) + pow(axis_y,2));

		rp1x = (dotr1/ (norm*norm)) * axis_x;
		rp1y = (dotr1/ (norm*norm)) * axis_y;
		rn1 = sqrt(pow(rp1x,2) + pow(rp1y,2));
		if (rp1x < 0) { rn1 = -1*rn1; }
		
		rp2x = (dotr2/ (norm*norm)) * axis_x;
		rp2y = (dotr2/ (norm*norm)) * axis_y;
		rn2 = sqrt(pow(rp2x,2) + pow(rp2y,2));
		if (rp2x < 0) { rn2 = -1*rn2;}



		proj1x = (dot_prod1 / (norm*norm)) * axis_x;
		proj1y = (dot_prod1 / (norm*norm)) * axis_y;
		normp1 = sqrt(pow(proj1x,2) + pow(proj1y,2));
		if (proj1x < 0) { normp1 = -1*normp1; }

		
		proj2x = (dot_prod2 / (norm*norm)) * axis_x;
		proj2y = (dot_prod2 / (norm*norm)) * axis_y;
		normp2 = sqrt(pow(proj2x,2) + pow(proj2y,2));
		if (proj2x < 0) { normp2 = -1*normp2; }


		proj3x = (dot_prod3 / (norm*norm)) * axis_x;
		proj3y = (dot_prod3 / (norm*norm)) * axis_y;
		normp3 = sqrt(pow(proj3x,2) + pow(proj3y,2));
		if (proj3x < 0) { normp3 = -1*normp3; }


		proj4x = (dot_prod4 / (norm*norm)) * axis_x;
		proj4y = (dot_prod4 / (norm*norm)) * axis_y;
		normp4 = sqrt(pow(proj4x,2) + pow(proj4y,2));
		if (proj4x < 0) { normp4 = -1*normp4; }
	

		// checking for over lap but only 2 points are needed
		if(normp1 >= normp2 && normp1 >= normp3 && normp1 >= normp4){
		       chp1x = proj1x; chp1y = proj1y; chn1 = normp1;
		}
		else if(normp2 >= normp1 && normp2 >= normp3 && normp2 >= normp4){
		       chp1x = proj2x; chp1y = proj2y; chn1 = normp2;
		}
		else if(normp3 >= normp1 && normp3 >= normp2 && normp3 >= normp4){
		       chp1x = proj3x; chp1y = proj3y; chn1 = normp3;
		}
		else{
		       chp1x = proj4x; chp1y = proj4y; chn1 = normp4;
		}
		
		if(normp1 <= normp2 && normp1 <= normp3 && normp1 <= normp4){
		       chp2x = proj1x; chp2y = proj1y; chn2 = normp1;
		}
		else if(normp2 <= normp1 && normp2 <= normp3 && normp2 <= normp4){
		       chp2x = proj2x; chp2y = proj2y; chn2 = normp2;
		}
		else if(normp3 <= normp1 && normp3 <= normp2 && normp3 <= normp4){
		       chp2x = proj3x; chp2y = proj3y; chn2 = normp3;
		}
		else{
		       chp2x = proj4x; chp2y = proj4y; chn2 = normp4;
		}

			
		// now the onlything left to checkis if projected line segment intersect
		// the axis is not at the origin this time so to get check if the 
		if(!(( rn1 >= std::min(chn1,chn2) && rn1 <= std::max(chn1,chn2)) || ( rn2 >= std::min(chn1,chn2) &&  rn2 <= std::max(chn1,chn2)) || ( chn1 >= std::min(rn1,rn2) &&  chn1 <= std::max(rn1,rn2)) || ( chn2 >= std::min(rn1, rn2) &&  chn2 <= std::max(rn1, rn2))))
		{
			good_axis = 1;
			break;
		}	
	}

	//obstacle was intersected
	if (good_axis == 0){
		return false;
	}

    }

    return true;
}

// Add any custom debug / development code here. This code will be executed
// instead of the statistics checker (Project2.cpp). Any code submitted here
// MUST compile, but will not be graded.
void debugMode(const std::vector<Robot> & /*robots*/, const std::vector<Rectangle> & /*obstacles*/,
               const std::vector<bool> & /*valid*/)
{
}
