///////////////////////////////////////
// COMP/ELEC/MECH 450/550
// Project 4
// Authors: Rhema Ike
//////////////////////////////////////

#include <iostream>

#include <ompl/control/SpaceInformation.h>
#include <ompl/base/spaces/SE2StateSpace.h>
#include <ompl/base/spaces/SO2StateSpace.h>
#include <ompl/control/spaces/RealVectorControlSpace.h>
#include <ompl/tools/benchmark/Benchmark.h>
#include <ompl/base/spaces/RealVectorStateSpace.h>
#include <ompl/config.h>
#include <valarray>
#include <limits>
#include <fstream>
#include <math.h>

#include <ompl/base/ProjectionEvaluator.h>

#include <ompl/control/SimpleSetup.h>
#include <ompl/control/ODESolver.h>

// The collision checker produced in project 2
#include "CollisionChecking.h"

// Add planners
//#include <ompl/control/planners/rrt/RRT.h>
#include <ompl/control/planners/est/EST.h>

#include "RRT.h"

namespace ob = ompl::base;
namespace oc = ompl::control;
namespace sp = std::placeholders;

void circlePostIntegration(const ob::State* /*state*/, const oc::Control* /*control*/, const double /*duration*/, ob::State *result)
{
    // Normalize orientation between 0 and 2*pi
    //ob::SO2StateSpace SO2;
    //SO2.enforceBounds(result->as<ob::SE2StateSpace::StateType>()->as<ob::SO2StateSpace::StateType>(1));
}

void circleODE(const ompl::control::ODESolver::StateType & q, const ompl::control::Control * control,
            ompl::control::ODESolver::StateType & qdot)
{
    //std::cout<<"in carODE"<<std::endl;
    // TODO: Fill in the ODE for the car's dynamics
    const double *u = control->as<oc::RealVectorControlSpace::ControlType>()->values;
    const double x = q[0];
    const double y = q[1];
    const double theta = u[0];
    const double speed = u[1];

    //Zero out qdot
    //qdot.resize(q.size(),0);
    //std::cout<<"x is "<<x<<" y is "<<y<<std::endl;
    //std::cout<<"speed is "<<speed<<" theta is "<<theta<<std::endl;
    //std::cout<<"initializing with qsize of "<< q.size()<<std::endl;
    //std::cout<<"speed "<<speed<<std::endl;
    //std::cout<<"qdot size"<<qdot.size()<<std::endl;

    qdot[0] = speed * cos(theta);
	qdot[1] = speed * sin(theta); 

    //std::cout<<"Done"<<std::endl;
}

bool isStateValid(const ob::State *state, const oc::SpaceInformation *si, std::vector<Rectangle> & obstacles)
{
    double radius = 0.5;
    bool validState = true;


    // Extract the real vector component (x, y)
    //std::cout<<"FIRST in"<<std::endl;
    auto r2state = state->as<ompl::base::RealVectorStateSpace::StateType>();
    //std::cout<<"After in"<<std::endl;
    double x = r2state->values[0];
    double y = r2state->values[1];
    //std::cout<<"Done"<<std::endl;

    validState = isValidCircle(x, y, radius, obstacles);
    //if (si->satisfiesBounds(state) )
     //   std::cout<<"StateValid"<<std::endl;
    //else
    //    std::cout<<"Not StateValid"<<std::endl;

    return si->satisfiesBounds(state) && validState;
}

void makeStreet(std::vector<Rectangle> & obstacles)
{
    Rectangle obstacle;
    // obstacle.x = -10;
    // obstacle.y = -10;
    // obstacle.width = 20;
    // obstacle.height = 2;
    // obstacles.push_back(obstacle);

    // obstacle.x = -10;
    // obstacle.y = -8;
    // obstacle.width = 2;
    // obstacle.height = 7;
    // obstacles.push_back(obstacle);

    // obstacle.x = 8;
    // obstacle.y = -8;
    // obstacle.width = 2;
    // obstacle.height = 6;
    // obstacles.push_back(obstacle);

    // obstacle.x = -10;
    // obstacle.y = -2;
    // obstacle.width = 8;
    // obstacle.height = 4;
    // obstacles.push_back(obstacle);

    // obstacle.x = 2;
    // obstacle.y = -2;
    // obstacle.width = 8;
    // obstacle.height = 4;
    // obstacles.push_back(obstacle);

    // obstacle.x = -10;
    // obstacle.y = 2;
    // obstacle.width = 2;
    // obstacle.height = 6;
    // obstacles.push_back(obstacle);

    // obstacle.x = 8;
    // obstacle.y = 2;
    // obstacle.width = 2;
    // obstacle.height = 6;
    // obstacles.push_back(obstacle);

    // obstacle.x = -10;
    // obstacle.y = 8,
    // obstacle.width = 20;
    // obstacle.height = 2;
    // obstacles.push_back(obstacle);

    obstacle.x = 4;
    obstacle.y = 4;
    obstacle.width = 1.2;
    obstacle.height = 1.2;
    obstacles.push_back(obstacle);

    obstacle.x = 4;
    obstacle.y = 7;
    obstacle.width = 1.2;
    obstacle.height = 1.2;
    obstacles.push_back(obstacle);

    obstacle.x = 7;
    obstacle.y = 7;
    obstacle.width = 1.2;
    obstacle.height = 1.2;
    obstacles.push_back(obstacle);

    obstacle.x = 7;
    obstacle.y = 4;
    obstacle.width = 1.2;
    obstacle.height = 1.2;
    obstacles.push_back(obstacle);
}

ompl::control::SimpleSetupPtr createCircle(std::vector<Rectangle> & obstacles, double* start_in, double* goal_in)
{
    //std::cout<<"setting up circle"<<std::endl;
    ompl::base::StateSpacePtr space;

    auto r2 = std::make_shared<ompl::base::RealVectorStateSpace>(2);

    /// set the bounds for the R^2 space
    ob::RealVectorBounds bounds(2);
    bounds.setLow(-2);
    bounds.setHigh(15);
    // bounds.setLow(-10);
    // bounds.setHigh(10);

    r2->setBounds(bounds);

    space = r2;

    // create a control space
    auto cspace(std::make_shared<oc::RealVectorControlSpace>(space,2));

    // set the bounds for the control space
    ob::RealVectorBounds cbounds(2);
    //cbounds.setLow(0,-0.5);
    //cbounds.setHigh(2*M_PI,0.5);
    cbounds.setLow(0);
    cbounds.setHigh(2*M_PI);

    cspace->setBounds(cbounds);

    // define a simple setup clas
    oc::SimpleSetup ss(cspace);

    // set state validity checking for this space
    oc::SpaceInformation *si = ss.getSpaceInformation().get();
    ss.setStateValidityChecker(std::bind(isStateValid, sp::_1, si, obstacles));
    // Use the ODESolver to propagate the system.  Call KinematicCarPostIntegration
    // when integration has finished to normalize the orientation values.
    auto odeSolver(std::make_shared<oc::ODEBasicSolver<>>(ss.getSpaceInformation(), &circleODE, 0.2));
    ss.setStatePropagator(oc::ODESolver::getStatePropagator(odeSolver, &circlePostIntegration));

    ompl::base::ScopedState<> start(space);
    start[0] = start_in[0];
    start[1] = start_in[1];

    ompl::base::ScopedState<> goal(space);
    goal[0] = goal_in[0];
    goal[1] = goal_in[1];

    // set the start and goal states with ?goal radius?
    ss.setStartAndGoalStates(start, goal, 0.03);
    auto ssptr(std::make_shared<oc::SimpleSetup>(ss));

    //std::cout<<"Done with creating"<<std::endl;
    return ssptr;
}

void planCircle(ompl::control::SimpleSetupPtr & ss, std::string path_name){

    ompl::base::StateSpace *space = ss->getStateSpace().get();
    auto planner = std::make_shared<ompl::control::RRT>(ss->getSpaceInformation());
    
    ss->setPlanner(planner);
    //std::cout<<"Done with planner set up"<<std::endl;
    ss->setup();
    //std::cout<<"Done with set up"<<std::endl;
    ob::PlannerStatus solved = ss->solve(10.0);
    //std::cout<<"Done with planner"<<std::endl;
    if (solved)
    {
        std::cout << "Found solution:" << std::endl;
        /// print the path to screen

        ss->getSolutionPath().asGeometric().printAsMatrix(std::cout);
        // print path to file
        std::ofstream fout(path_name);
        fout << "R2" << std::endl;
        ss->getSolutionPath().asGeometric().printAsMatrix(fout);
        fout.close();
    }
    else
        std::cout << "No solution found"<< path_name << std::endl;

}

int main(int argc, char ** argv)
{
    std::vector<Rectangle> obstacles;
    std::vector<double *> robot_start;
    std::vector<double *> robot_goal;
    std::vector<std::string> path;

    // double r1s[2] = {-5,5}; double r1g[2] = {5,-5};
    // double r2s[2] = {5,-5}; double r2g[2] = {-5,5};
    // double r3s[2] = {5,5}; double r3g[2] = {-5,-5};
    // double r4s[2] = {-5,-5}; double r4g[2] = {5,5};
    double r1s[2] = {1,1}; double r1g[2] = {10,10};
    double r2s[2] = {1,3}; double r2g[2] = {10,12};
    double r3s[2] = {3,3}; double r3g[2] = {12,12};
    double r4s[2] = {3,1}; double r4g[2] = {12,10};
    double r5s[2] = {1,10}; double r5g[2] = {10,1};
    double r6s[2] = {1,12}; double r6g[2] = {10,3};
    double r7s[2] = {3,12}; double r7g[2] = {12,3};
    double r8s[2] = {3,10}; double r8g[2] = {12,1};
    double r9s[2] = {10,10}; double r9g[2] = {1,1};
    double r10s[2] = {10,12}; double r10g[2] = {1,3};
    double r11s[2] = {12,12}; double r11g[2] = {3,3};
    double r12s[2] = {12,10}; double r12g[2] = {3,1};
    double r13s[2] = {10,1}; double r13g[2] = {1,10};
    double r14s[2] = {10,3}; double r14g[2] = {1,12};
    double r15s[2] = {12,3}; double r15g[2] = {3,12};
    double r16s[2] = {12,1}; double r16g[2] = {3,10};
    // double r5s[2] = {7,2}; double r5g[2] = {1,2};
    // double r6s[2] = {3,4}; double r6g[2] = {2,8};

    robot_start.push_back(r1s); robot_goal.push_back(r1g);
    robot_start.push_back(r2s); robot_goal.push_back(r2g);
    robot_start.push_back(r3s); robot_goal.push_back(r3g);
    robot_start.push_back(r4s); robot_goal.push_back(r4g);
    robot_start.push_back(r5s); robot_goal.push_back(r5g);
    robot_start.push_back(r6s); robot_goal.push_back(r6g);
    robot_start.push_back(r7s); robot_goal.push_back(r7g);
    robot_start.push_back(r8s); robot_goal.push_back(r8g);
    robot_start.push_back(r9s); robot_goal.push_back(r9g);
    robot_start.push_back(r10s); robot_goal.push_back(r10g);
    robot_start.push_back(r11s); robot_goal.push_back(r11g);
    robot_start.push_back(r12s); robot_goal.push_back(r12g);
    robot_start.push_back(r13s); robot_goal.push_back(r13g);
    robot_start.push_back(r14s); robot_goal.push_back(r14g);
    robot_start.push_back(r15s); robot_goal.push_back(r15g);
    robot_start.push_back(r16s); robot_goal.push_back(r16g);

    path.push_back("srcPython/paths2/path1.txt");
    path.push_back("srcPython/paths2/path2.txt");
    path.push_back("srcPython/paths2/path3.txt");
    path.push_back("srcPython/paths2/path4.txt");
    path.push_back("srcPython/paths2/path5.txt");
    path.push_back("srcPython/paths2/path6.txt");
    path.push_back("srcPython/paths2/path7.txt");
    path.push_back("srcPython/paths2/path8.txt");
    path.push_back("srcPython/paths2/path9.txt");
    path.push_back("srcPython/paths2/path10.txt");
    path.push_back("srcPython/paths2/path11.txt");
    path.push_back("srcPython/paths2/path12.txt");
    path.push_back("srcPython/paths2/path13.txt");
    path.push_back("srcPython/paths2/path14.txt");
    path.push_back("srcPython/paths2/path15.txt");
    path.push_back("srcPython/paths2/path16.txt");
    
    // robot_start.push_back(r5s); robot_goal.push_back(r5g);
    // robot_start.push_back(r6s); robot_goal.push_back(r6g);


    makeStreet(obstacles);

    for(int i = 0; i < robot_goal.size(); i++){
        ompl::control::SimpleSetupPtr ss = createCircle(obstacles,  robot_start[i], robot_goal[i]);
        planCircle(ss,path[i]);
    }

    

    return 0;
}